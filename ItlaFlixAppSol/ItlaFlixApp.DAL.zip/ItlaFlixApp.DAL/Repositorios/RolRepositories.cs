﻿namespace ItlaFlixApp.DAL.Repositorios
{
    internal class RolRepositories
    {
    }
}
