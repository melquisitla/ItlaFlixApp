﻿namespace ItlaFlixApp.DAL.Repositorios
{
    internal class GenderRepositories
    {
    }
}
