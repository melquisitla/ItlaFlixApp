﻿namespace ItlaFlixApp.DAL.Repositorios
{
    internal class SaleRepositories
    {
    }
}
