﻿namespace ItlaFlixApp.DAL.Repositorios
{
    internal class MoviesRepositories
    {
    }
}
