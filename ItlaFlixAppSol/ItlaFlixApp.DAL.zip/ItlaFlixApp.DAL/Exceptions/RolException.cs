﻿namespace ItlaFlixApp.DAL.Exceptions
{
    public class RolException
    {
    }
}
