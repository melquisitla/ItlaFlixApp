﻿using ItlaFlixApp.DAL.Core;

namespace ItlaFlixApp.DAL.Entities
{
    public class Gender : Descripcion
    {
        //public int cod_genero { get; set; }
    }
}
