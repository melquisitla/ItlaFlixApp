﻿using ItlaFlixApp.DAL.Core;

namespace ItlaFlixApp.DAL.Entities
{
    public class Movies_Gender : BaseEntity
    {
        //public int cod_genero { get; set; }
    }
}
