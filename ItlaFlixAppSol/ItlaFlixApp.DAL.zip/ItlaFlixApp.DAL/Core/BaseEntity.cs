﻿
namespace ItlaFlixApp.DAL.Core
{
    public abstract class BaseEntity
    {
        public int cod_pelicula { get; set; }
        public int cod_usuario { get; set; }
        public int cod_genero { get; set; }
    }
}
