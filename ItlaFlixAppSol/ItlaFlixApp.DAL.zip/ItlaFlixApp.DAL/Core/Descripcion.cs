﻿namespace ItlaFlixApp.DAL.Core
{
    public class Descripcion : BaseEntity
    {
        public string? txt_Descriptions { get; set; }
    }
}
