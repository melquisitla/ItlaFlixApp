﻿namespace ItlaFlixApp.DAL.Core
{
    public class IDbFactory
    {

    }
}
