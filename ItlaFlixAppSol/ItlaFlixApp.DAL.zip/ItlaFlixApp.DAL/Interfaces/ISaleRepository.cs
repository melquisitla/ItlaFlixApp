﻿namespace ItlaFlixApp.DAL.Interfaces
{
    public interface ISaleRepository
    {
    }
}
